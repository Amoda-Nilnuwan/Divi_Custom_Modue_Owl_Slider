// import HelloWorld from './HelloWorld/HelloWorld';
import OwlCarousel from './OwlCarousel/OwlCarousel';
import OwlCarouselChild from './OwlCarouselChild/OwlCarouselChild';

// export default [HelloWorld];
export default [
    OwlCarousel,
    OwlCarouselChild
];
