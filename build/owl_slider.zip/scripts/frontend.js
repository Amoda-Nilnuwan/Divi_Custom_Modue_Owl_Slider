// This script is loaded both on the frontend page and in the Visual Builder.

jQuery(function($) {

    // window.ETBuilderBackendDynamic.shortcode_object[1].content[0].content[0].content[0].content[0].attrs.percent= '20';
});
